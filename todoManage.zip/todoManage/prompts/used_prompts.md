Q. 과제내용 전달 및 전반적인 소스 구조와 틀을 요청
A. 전반적인 소스 구조와 틀 응답

Q. schema.sql 자동으로 실행하는 방법
A. spring.sql.init.mode=always 설정

Q. spring.sql.init.mode=always 사용 시 오류
A. spring.sql.init.schema-locations=classpath:schema.sql 로 사용할 파일 명시

Q. 데이터베이스의 스네이크 케이스 컬럼명을 카멜 케이스 필드로 자동으로 매핑하는 설정
A. mybatis.configuration.map-underscore-to-camel-case=true 설정

Q. Parameter 0 of constructor in com.todomanage.config.JwtConfig required a bean of type 'com.todomanage.jwt.JwtAuthenticationFilter' that could not be found.
A. Spring이 JwtConfig 클래스를 생성하려고 할 때, 생성자에서 JwtAuthenticationFilter 타입의 빈(Bean)을 주입받으려 하지만, 해당 타입의 빈을 애플리케이션 컨텍스트에서 찾을 수 없어서 발생하는 오류

Q. Consider defining a bean of type 'com.todomanage.jwt.JwtAuthenticationFilter' in your configuration.
A. Spring이 JwtAuthenticationFilter를 주입하려고 했지만 해당 필터가 Spring 빈으로 등록되지 않아서 발생하는 오류

Q. No property 'username' found for type 'User'; Did you mean 'userName'?
A. findByUsername(String username)이라는 이름으로 쿼리를 만들려고 했는데, User 클래스에 username이라는 필드가 없기 때문에 실패

Q. SQLite 기반 DB툴 사이트 요청
A. SQLite 기반 DB툴 사이트

Q. IllegalArgumentException: Name for argument of type [int] not specified, and parameter name information not available via reflection 오류의 원인
A. 만약 @PathVariable에 대한 인식이 제대로 되지 않는다면, id 이름을 @PathVariable("id")와 같이 명시적으로 지정해 줄 수 있습니다.

Q. 필요한 테스트케이스 전달 및 전반적인 소스 구조와 틀을 요청
A. 테스트케이스 소스 구조와 틀 응답

Q. 테스트케이스에서 TODO를 두번 생성
A. TODO insert를 두번하는 소스 응답

Q. 전반적인 소스, 주석 정리 요청
A. 정리된 소스

