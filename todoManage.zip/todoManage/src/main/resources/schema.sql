-- users 테이블 생성 (사용자 정보 저장)
CREATE TABLE IF NOT EXISTS users (
    user_no INTEGER PRIMARY KEY AUTOINCREMENT,  -- 사용자 번호 (기본키, 자동 증가)
    user_id TEXT NOT NULL UNIQUE,               -- 사용자 ID (유니크 값)
    user_name TEXT NOT NULL,                    -- 사용자 이름
    password TEXT NOT NULL,                     -- 비밀번호
    email TEXT NOT NULL                         -- 이메일
);

-- todos 테이블 생성 (할 일 정보 저장)
CREATE TABLE IF NOT EXISTS todos (
    todo_no INTEGER PRIMARY KEY AUTOINCREMENT, -- 할 일 번호 (기본키, 자동 증가)
    title TEXT NOT NULL,                       -- 할 일 제목
    description TEXT,                          -- 할 일 설명
    completed BOOLEAN NOT NULL DEFAULT 0,      -- 할 일 완료 여부 (기본값은 0)
    user_no INTEGER,                           -- 사용자 번호 (users 테이블과 외래키 관계)
    FOREIGN KEY (user_no) REFERENCES users(user_no)  -- users 테이블과 외래키 제약
);
