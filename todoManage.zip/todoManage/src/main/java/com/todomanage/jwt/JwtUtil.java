package com.todomanage.jwt;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JwtUtil {

    private static final Logger log = LoggerFactory.getLogger(JwtUtil.class);

    // SecretKey는 안전하게 환경 변수나 설정 파일에서 관리
    private static final String SECRET = "mysecretkeymysecretkeymysecretkeymysecretkey";  // 32바이트 이상
    private final SecretKey SECRET_KEY = Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));

    private final long EXPIRATION_TIME = 1000 * 60 * 60;  // 토큰 유효 기간 (1시간)

    private final JwtParser parser = Jwts.parserBuilder()
            .setSigningKey(SECRET_KEY)
            .build();

    // 토큰에서 Claims 추출
    public Claims getClaims(String token) {
        return parser.parseClaimsJws(token.replace("Bearer ", "")).getBody();
    }

    // 토큰에서 사용자 번호 추출
    public int extractUserNo(String token) {
        Number userNo = getClaims(token).get("userNo", Number.class);
        return userNo.intValue();
    }

    // 토큰에서 사용자 이름 추출
    public String extractUsername(String token) {
        return extractAllClaims(token).getSubject();
    }

    // 모든 Claims 추출
    private Claims extractAllClaims(String token) {
        return parser.parseClaimsJws(token.replace("Bearer ", "")).getBody();
    }

    // JWT 토큰 생성
    public String generateToken(int userNo, String username) {
        return Jwts.builder()
                .setSubject(username)
                .claim("userNo", userNo)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(SECRET_KEY)
                .compact();
    }

    // 토큰 유효성 검사
    public boolean isTokenValid(String token) {
        try {
            return !isTokenExpired(token);
        } catch (Exception e) {
            log.error("JWT validation error: {}", e.getMessage());
            return false;
        }
    }

    // 토큰 만료 여부 검사
    private boolean isTokenExpired(String token) {
        return extractAllClaims(token).getExpiration().before(new Date());
    }
}
