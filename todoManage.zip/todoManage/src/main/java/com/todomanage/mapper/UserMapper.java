package com.todomanage.mapper;

import com.todomanage.dto.UserDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.Optional;

@Mapper
public interface UserMapper {

    // 사용자를 추가하는 메서드
    void insertUser(UserDto user);

    // 마지막 삽입된 사용자의 ID를 가져오는 메서드
    int getLastInsertId();

    // 사용자 ID로 사용자를 조회하는 메서드
    UserDto selectUserById(String userId);

    // 사용자 번호로 사용자를 조회하는 메서드
    Optional<UserDto> selectUserByUserNo(int userNo);

    // 사용자 정보를 업데이트하는 메서드
    void updateUser(UserDto user);

    // 사용자 번호로 사용자를 삭제하는 메서드
    void deleteUser(int userNo);
}
