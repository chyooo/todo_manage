package com.todomanage.mapper;

import com.todomanage.dto.TodoDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TodoMapper {

    // 할 일을 추가하는 메서드
    void insertTodo(TodoDto todo);

    // 마지막 삽입된 Todo의 ID를 가져오는 메서드
    int getLastInsertId();

    // 특정 ID에 해당하는 Todo를 조회하는 메서드
    TodoDto selectTodoById(@Param("id") int id);

    // 특정 사용자 번호에 해당하는 모든 Todo를 조회하는 메서드
    List<TodoDto> selectTodosByUserNo(@Param("userNo") int userNo);

    // 사용자의 번호와 검색어를 기준으로 Todo를 검색하는 메서드
    List<TodoDto> searchTodosByUserNoAndQuery(
        @Param("userNo") int userNo,
        @Param("query") String query
    );

    // Todo를 업데이트하는 메서드
    void updateTodo(TodoDto todo);

    // 특정 ID에 해당하는 Todo를 삭제하는 메서드
    void deleteTodo(@Param("id") int id);
}
