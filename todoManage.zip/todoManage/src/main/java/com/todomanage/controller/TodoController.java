package com.todomanage.controller;

import com.todomanage.dto.TodoDto;
import com.todomanage.service.TodoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
public class TodoController {

    private final TodoService todoService; // TodoService 의존성 주입

    public TodoController(TodoService todoService) {
        this.todoService = todoService;  // TodoService 주입
    }

    // 모든 Todo를 조회하는 API
    @GetMapping
    public ResponseEntity<List<TodoDto>> getAllTodos(@RequestHeader("Authorization") String authHeader) {
        String token = authHeader.split(" ")[1]; // Authorization 헤더에서 토큰 추출
        List<TodoDto> todos = todoService.getAllTodos(token); // 서비스에서 Todo 목록 가져오기
        return todos != null ? new ResponseEntity<>(todos, HttpStatus.OK)  // Todo 목록 반환
                             : new ResponseEntity<>(HttpStatus.UNAUTHORIZED); // 인증 실패 시 401 반환
    }

    // 새로운 Todo를 생성하는 API
    @PostMapping
    public ResponseEntity<TodoDto> createTodo(@RequestHeader("Authorization") String authHeader, @RequestBody TodoDto todoDto) {
        String token = authHeader.split(" ")[1];  // 토큰 추출
        TodoDto createdTodo = todoService.createTodo(todoDto, token);  // Todo 생성
        return createdTodo != null ? new ResponseEntity<>(createdTodo, HttpStatus.CREATED)  // 생성된 Todo 반환
                                  : new ResponseEntity<>(HttpStatus.UNAUTHORIZED); // 인증 실패 시 401 반환
    }

    // Todo 수정하는 API
    @PutMapping("/{id}")
    public ResponseEntity<TodoDto> updateTodo(@PathVariable("id") int id, @RequestHeader("Authorization") String authHeader, @RequestBody TodoDto todoDto) {
        String token = authHeader.split(" ")[1];  // 토큰 추출
        TodoDto updatedTodo = todoService.updateTodo(id, todoDto, token);  // Todo 수정
        return updatedTodo != null ? new ResponseEntity<>(updatedTodo, HttpStatus.OK) // 수정된 Todo 반환
                                   : new ResponseEntity<>(HttpStatus.NOT_FOUND); // Todo 없음
    }

    // Todo 삭제하는 API
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable("id") int id, @RequestHeader("Authorization") String authHeader) {
        String token = authHeader.split(" ")[1];  // 토큰 추출
        boolean deleted = todoService.deleteTodo(id, token);  // Todo 삭제
        return deleted ? new ResponseEntity<>(HttpStatus.NO_CONTENT)  // 삭제 성공 시 204 반환
                       : new ResponseEntity<>(HttpStatus.NOT_FOUND);  // Todo 없음
    }

    // 단일 Todo 조회 API
    @GetMapping("/{id}")
    public ResponseEntity<TodoDto> getTodoById(@PathVariable("id") int id, @RequestHeader("Authorization") String authHeader) {
        String token = authHeader.split(" ")[1];  // 토큰 추출
        TodoDto todo = todoService.getTodoById(id, token);  // Todo 조회
        return todo != null ? new ResponseEntity<>(todo, HttpStatus.OK) // 조회된 Todo 반환
                            : new ResponseEntity<>(HttpStatus.NOT_FOUND); // Todo 없음
    }

    // Todo 제목 또는 설명을 검색하는 API
    @GetMapping("/search")
    public ResponseEntity<List<TodoDto>> searchTodos(@RequestParam String query, @RequestHeader("Authorization") String authHeader) {
        String token = authHeader.split(" ")[1];  // 토큰 추출
        List<TodoDto> todos = todoService.searchTodos(query, token); // 검색된 Todo 목록 반환
        return todos != null ? new ResponseEntity<>(todos, HttpStatus.OK)  // 검색 결과 반환
                             : new ResponseEntity<>(HttpStatus.UNAUTHORIZED);  // 인증 실패 시 401 반환
    }
}
