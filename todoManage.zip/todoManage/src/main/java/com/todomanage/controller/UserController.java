package com.todomanage.controller;

import com.todomanage.dto.UserDto;
import com.todomanage.service.UserService;
import com.todomanage.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;  // 사용자 관리 서비스
    private final AuthService authService;  // 인증 서비스

    public UserController(UserService userService, AuthService authService) {
        this.userService = userService;  // UserService 주입
        this.authService = authService;  // AuthService 주입
    }

    @PostMapping("/signup")
    public ResponseEntity<UserDto> createUser(@RequestBody UserDto userDto) {
        // 사용자 가입 처리 API
        if (userDto == null || userDto.getUserName() == null || userDto.getPassword() == null || userDto.getEmail() == null) {
            // 필요한 정보가 부족하면 400 Bad Request 반환
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        // 사용자 ID 중복 체크
        if (userService.getUser(userDto.getUserId()) != null) {
            // 이미 존재하는 아이디라면 409 Conflict 반환
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        UserDto createdUser = userService.createUser(userDto); // 사용자 생성
        return createdUser != null ? new ResponseEntity<>(createdUser, HttpStatus.CREATED)  // 생성된 사용자 반환
                                  : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // 생성 실패 시 500 반환
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserDto userDto) {
        // 사용자 로그인 처리 API
        if (userDto == null || userDto.getUserId() == null || userDto.getPassword() == null) {
            // 로그인 정보 부족 시 400 Bad Request 반환
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        String token = authService.authenticateUser(userDto);  // 사용자 인증 후 토큰 생성
        return token != null && !token.isEmpty() 
                ? new ResponseEntity<>(token, HttpStatus.OK)  // 로그인 성공 시 토큰 반환
                : new ResponseEntity<>(HttpStatus.UNAUTHORIZED);  // 인증 실패 시 401 반환
    }

    @GetMapping("/me")
    public ResponseEntity<UserDto> getCurrentUser(@RequestHeader("Authorization") String authHeader) {
        // 로그인된 사용자의 정보 조회 API
        String token = authHeader.split(" ")[1];  // 토큰 추출
        UserDto user = authService.getUserFromToken(token);  // 사용자 정보 조회
        return user != null ? new ResponseEntity<>(user, HttpStatus.OK)  // 사용자 정보 반환
                            : new ResponseEntity<>(HttpStatus.UNAUTHORIZED);  // 인증 실패 시 401 반환
    }

    @PutMapping("/me")
    public ResponseEntity<UserDto> updateUser(@RequestHeader("Authorization") String authHeader, @RequestBody UserDto userDto) {
        // 로그인된 사용자의 정보 수정 API
        String token = authHeader.split(" ")[1];  // 토큰 추출
        UserDto updatedUser = authService.updateUserFromToken(token, userDto);  // 사용자 정보 수정
        return updatedUser != null ? new ResponseEntity<>(updatedUser, HttpStatus.OK)  // 수정된 사용자 정보 반환
                                   : new ResponseEntity<>(HttpStatus.UNAUTHORIZED);  // 인증 실패 시 401 반환
    }

    @DeleteMapping("/me")
    public ResponseEntity<Void> deleteUser(@RequestHeader("Authorization") String authHeader) {
        // 로그인된 사용자 삭제 API
        String token = authHeader.split(" ")[1];  // 토큰 추출
        boolean deleted = authService.deleteUserFromToken(token);  // 사용자 삭제
        return deleted ? new ResponseEntity<>(HttpStatus.NO_CONTENT)  // 삭제 성공 시 204 반환
                       : new ResponseEntity<>(HttpStatus.UNAUTHORIZED);  // 인증 실패 시 401 반환
    }
}
