package com.todomanage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoManageApplication {
    public static void main(String[] args) {
        SpringApplication.run(TodoManageApplication.class, args);
    }
}
