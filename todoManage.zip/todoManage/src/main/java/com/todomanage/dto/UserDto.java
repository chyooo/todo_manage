package com.todomanage.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor 
@NoArgsConstructor
public class UserDto {

    private int userNo;      // 사용자 번호 (기본 키)
    private String userId;   // 사용자 ID (고유값)
    private String userName; // 사용자 이름
    private String password; // 사용자 비밀번호
    private String email;    // 사용자 이메일
}
