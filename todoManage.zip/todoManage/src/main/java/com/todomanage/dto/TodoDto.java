package com.todomanage.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TodoDto {

    private int todoNo;       // 할 일 번호 (기본 키)
    private String title;     // 할 일 제목
    private String description;  // 할 일 설명
    private boolean completed;   // 할 일 완료 여부
    private int userNo;       // 사용자 번호 (users 테이블과 외래키 관계)
}
