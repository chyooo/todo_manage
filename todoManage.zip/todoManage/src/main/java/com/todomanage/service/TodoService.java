package com.todomanage.service;

import com.todomanage.dto.TodoDto;
import com.todomanage.jwt.JwtUtil;
import com.todomanage.mapper.TodoMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoService {

    private final TodoMapper todoMapper;
    private final JwtUtil jwtUtil;

    public TodoService(TodoMapper todoMapper, JwtUtil jwtUtil) {
        this.todoMapper = todoMapper;
        this.jwtUtil = jwtUtil;
    }

    // 모든 Todo 목록 조회
    public List<TodoDto> getAllTodos(String token) {
        if (!jwtUtil.isTokenValid(token)) return null;  // 유효하지 않은 토큰이면 null 반환
        int userNo = jwtUtil.extractUserNo(token);
        return todoMapper.selectTodosByUserNo(userNo);  // 사용자 번호로 Todo 목록 조회
    }

    // 새 Todo 생성
    public TodoDto createTodo(TodoDto todoDto, String token) {
        if (!jwtUtil.isTokenValid(token)) return null;
        int userNo = jwtUtil.extractUserNo(token);
        todoDto.setUserNo(userNo);
        todoMapper.insertTodo(todoDto);
        int todoNo = todoMapper.getLastInsertId();  // 마지막에 삽입된 Todo ID 조회
        return todoMapper.selectTodoById(todoNo);  // 생성된 Todo 반환
    }

    // Todo 수정
    public TodoDto updateTodo(int id, TodoDto todoDto, String token) {
        if (!jwtUtil.isTokenValid(token)) return null;
        TodoDto existing = todoMapper.selectTodoById(id);
        if (existing != null) {
            todoDto.setTodoNo(id);
            todoDto.setUserNo(existing.getUserNo());
            todoMapper.updateTodo(todoDto);
            return todoMapper.selectTodoById(id);  // 수정된 Todo 반환
        }
        return null;
    }

    // Todo 삭제
    public boolean deleteTodo(int id, String token) {
        if (!jwtUtil.isTokenValid(token)) return false;
        TodoDto todo = todoMapper.selectTodoById(id);
        if (todo != null) {
            todoMapper.deleteTodo(id);
            return true;
        }
        return false;
    }

    // Todo ID로 조회
    public TodoDto getTodoById(int id, String token) {
        if (!jwtUtil.isTokenValid(token)) return null;
        return todoMapper.selectTodoById(id);  // Todo ID로 Todo 조회
    }

    // Todo 검색
    public List<TodoDto> searchTodos(String query, String token) {
        if (!jwtUtil.isTokenValid(token)) return null;
        int userNo = jwtUtil.extractUserNo(token);
        return todoMapper.searchTodosByUserNoAndQuery(userNo, query);  // 사용자 번호와 검색 쿼리로 Todo 검색
    }
}
