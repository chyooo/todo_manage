package com.todomanage.service;

import com.todomanage.dto.UserDto;
import com.todomanage.mapper.UserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;

    public UserService(UserMapper userMapper, PasswordEncoder passwordEncoder) {
        this.userMapper = userMapper;
        this.passwordEncoder = passwordEncoder;
    }

    // 사용자 생성
    public UserDto createUser(UserDto userDto) {
        String encodedPassword = passwordEncoder.encode(userDto.getPassword());  // 비밀번호 암호화
        userDto.setPassword(encodedPassword);

        userMapper.insertUser(userDto);  // 사용자 정보 DB에 삽입
        int userNo = userMapper.getLastInsertId();  // 새로 삽입된 사용자 ID 조회

        UserDto createdUser = userMapper.selectUserByUserNo(userNo).orElse(null);  // 새로 생성된 사용자 조회

        return createdUser;  // 생성된 사용자 반환
    }

    // 사용자 ID로 사용자 정보 조회
    public UserDto getUser(String userId) {
        return userMapper.selectUserById(userId);  // 주어진 userId로 사용자 정보 조회
    }
}
