package com.todomanage.service;

import com.todomanage.dto.UserDto;
import com.todomanage.jwt.JwtUtil;
import com.todomanage.mapper.UserMapper;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final UserMapper userMapper; // 사용자 데이터베이스 접근을 위한 Mapper
    private final JwtUtil jwtUtil;       // JWT 토큰 생성 및 검증을 위한 유틸리티
    private final PasswordEncoder passwordEncoder; // 비밀번호 암호화를 위한 인코더

    // 생성자 주입을 통한 의존성 주입
    public AuthService(UserMapper userMapper, JwtUtil jwtUtil, PasswordEncoder passwordEncoder) {
        this.userMapper = userMapper;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }

    // 사용자 인증 후 JWT 토큰을 생성하는 메소드
    public String authenticateUser(UserDto userDto) {
        UserDto user = userMapper.selectUserById(userDto.getUserId()); // 사용자 조회
        if (user != null && passwordEncoder.matches(userDto.getPassword(), user.getPassword())) {
            // 비밀번호가 일치하면 JWT 토큰 생성
            return jwtUtil.generateToken(user.getUserNo(), user.getUserName());
        }
        throw new RuntimeException("Invalid credentials"); // 인증 실패시 예외 발생
    }

    // JWT 토큰을 통해 사용자 정보를 조회하는 메소드
    public UserDto getUserFromToken(String token) {
        int userNo = jwtUtil.extractUserNo(token); // 토큰에서 사용자 번호 추출
        Optional<UserDto> userOptional = userMapper.selectUserByUserNo(userNo); // 사용자 조회
        return userOptional.orElse(null); // 사용자 존재하지 않으면 null 반환
    }

    // JWT 토큰을 통해 사용자 정보를 업데이트하는 메소드
    public UserDto updateUserFromToken(String token, UserDto userDto) {
        int userNo = jwtUtil.extractUserNo(token); // 토큰에서 사용자 번호 추출
        Optional<UserDto> userOptional = userMapper.selectUserByUserNo(userNo); // 사용자 조회
        if (userOptional.isPresent()) {
            UserDto user = userOptional.get();
            user.setPassword(passwordEncoder.encode(userDto.getPassword())); // 비밀번호 암호화 후 설정
            user.setEmail(userDto.getEmail()); // 이메일 설정
            userMapper.updateUser(user); // 사용자 정보 업데이트
            return new UserDto(user.getUserNo(), user.getUserId(), user.getUserName(), "", user.getEmail());
        }
        return null; // 사용자 없음
    }

    // JWT 토큰을 통해 사용자 정보를 삭제하는 메소드
    public boolean deleteUserFromToken(String token) {
        int userNo = jwtUtil.extractUserNo(token); // 토큰에서 사용자 번호 추출
        Optional<UserDto> userOptional = userMapper.selectUserByUserNo(userNo); // 사용자 조회
        if (userOptional.isPresent()) {
            userMapper.deleteUser(userOptional.get().getUserNo()); // 사용자 삭제
            return true;
        }
        return false; // 사용자 없음
    }
}
