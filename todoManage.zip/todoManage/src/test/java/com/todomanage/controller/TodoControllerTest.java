package com.todomanage.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.todomanage.dto.TodoDto;
import com.todomanage.dto.UserDto;

import ch.qos.logback.core.ConsoleAppender;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class TodoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private static final Logger log = LoggerFactory.getLogger(TodoControllerTest.class);  // 변경된 로그 클래스
    private final ObjectMapper objectMapper = new ObjectMapper(); // ObjectMapper 인스턴스
    private String jwtToken;
    private int createdTodoId;

    private final String BASE_URL = "/api/todos";

    @BeforeEach
    void setup() throws Exception {
        // 회원가입 및 로그인
        log.debug("0-1. 회원가입 시작");
        
        // UserDto 객체 생성
        UserDto userDto = new UserDto();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        userDto.setUserId("testUser" + LocalDateTime.now().format(formatter));
        userDto.setUserName("testUser");
        userDto.setPassword("testPassword");
        userDto.setEmail("test@example.com");

        log.info("0-2. 회원가입 요청 데이터: {}", objectMapper.writeValueAsString(userDto));

        try {
            // 회원가입 요청
            mockMvc.perform(post("/api/users/signup")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(userDto)))
                    .andExpect(status().isCreated());

            log.info("0-3. 회원가입 완료");

        } catch (Exception e) {
            log.error("0-4. 회원가입 중 에러 발생", e);
            throw e;
        }

        log.info("0-5. 로그인 시작");

        try {
            // 로그인 → JWT 토큰 발급
            String token = mockMvc.perform(post("/api/users/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(userDto)))
                    .andExpect(status().isOk())
                    .andExpect(content().string(Matchers.matchesPattern("^\\S+\\.\\S+\\.\\S+$"))) // 정규식으로 JWT 패턴 체크
                    .andReturn().getResponse().getContentAsString();

            jwtToken = "Bearer " + token;

            log.info("0-6. 로그인 완료 - JWT 발급: {}", jwtToken);
            

        } catch (Exception e) {
            log.error("0-7. 로그인 중 에러 발생", e);
            throw e;
        }
    }


    @Test
    void testTodoLifecycle() throws Exception {
        // 1. TODO 생성
        log.info("1-1. TODO 생성 시작");

        TodoDto todoDto = new TodoDto();
        todoDto.setTitle("Test Todo");
        todoDto.setDescription("This is a test todo");
        todoDto.setCompleted(false);

        try {
            // 첫 번째 TODO 생성
            String todoResponse = mockMvc.perform(post(BASE_URL)
                            .header("Authorization", jwtToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(todoDto)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.title").value("Test Todo"))
                    .andReturn().getResponse().getContentAsString();

            TodoDto createdTodo = objectMapper.readValue(todoResponse, TodoDto.class);
            createdTodoId = createdTodo.getTodoNo();
            log.info("1-2 Created Todo1: {}", objectMapper.writeValueAsString(createdTodo));

            assertThat(createdTodoId).isGreaterThan(0);

            // 두 번째 TODO 생성 (테스트 목적, 이후 흐름에 영향 X)
            TodoDto anotherTodoDto = new TodoDto();
            anotherTodoDto.setTitle("Another Test Todo");
            anotherTodoDto.setDescription("This is another test todo");
            anotherTodoDto.setCompleted(false);

            String anotherResponse = mockMvc.perform(post(BASE_URL)
                    .header("Authorization", jwtToken)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(anotherTodoDto)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.title").value("Another Test Todo"))
                    .andReturn().getResponse().getContentAsString();
            
            TodoDto anotherCreatedTodoDto = objectMapper.readValue(anotherResponse, TodoDto.class);

            log.info("1-3 Created Todo2: {}", objectMapper.writeValueAsString(anotherCreatedTodoDto));
        } catch (Exception e) {
            log.error("1-4. TODO 생성 중 에러 발생", e);
            throw e;
        }

        // 2. 목록 조회
        log.info("2-1. 목록 조회 시작");

        try {
            String listResponse = mockMvc.perform(get(BASE_URL)
                            .header("Authorization", jwtToken))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").isArray())
                    .andExpect(jsonPath("$[?(@.todoNo == " + createdTodoId + ")]").exists())
                    .andReturn().getResponse().getContentAsString();

            log.info("Response: {}", listResponse);  // 목록 조회 응답 출력
            log.info("2-2. 목록 조회 완료");
        } catch (Exception e) {
            log.error("2-3. 목록 조회 중 에러 발생", e);
            throw e;
        }

        // 3. 단일 조회
        log.info("3-1. 단일 조회 시작");

        try {
            String singleResponse = mockMvc.perform(get(BASE_URL + "/" + createdTodoId)
                            .header("Authorization", jwtToken))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.title").value("Test Todo"))
                    .andReturn().getResponse().getContentAsString();

            log.info("Response: {}", singleResponse);  // 단일 조회 응답 출력
            log.info("3-2. 단일 조회 완료");
        } catch (Exception e) {
            log.error("3-3. 단일 조회 중 에러 발생", e);
            throw e;
        }

        // 4. 수정
        log.info("4-1. 수정 시작");

        try {
            TodoDto updatedTodo = new TodoDto();
            updatedTodo.setTitle("Updated Title");
            updatedTodo.setDescription("Updated Description");
            updatedTodo.setCompleted(true);

            String updatedResponse = mockMvc.perform(put(BASE_URL + "/" + createdTodoId)
                            .header("Authorization", jwtToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(updatedTodo)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.title").value("Updated Title"))
                    .andExpect(jsonPath("$.completed").value(true))
                    .andReturn().getResponse().getContentAsString();

            log.info("Updated Todo Response: {}", updatedResponse);  // 수정된 Todo 응답 출력
            log.info("4-2. 수정 완료");
        } catch (Exception e) {
            log.error("4-3. 수정 중 에러 발생", e);
            throw e;
        }

        // 5. 삭제
        log.info("5-1. 삭제 시작");

        try {
            mockMvc.perform(delete(BASE_URL + "/" + createdTodoId)
                            .header("Authorization", jwtToken))
                    .andExpect(status().isNoContent());

            log.info("5-2. 삭제 완료");
        } catch (Exception e) {
            log.error("5-3. 삭제 중 에러 발생", e);
            throw e;
        }

        // 6. 삭제 후 조회 시 404
        log.info("6-1. 삭제 후 조회 시 404 시작");

        try {
            mockMvc.perform(get(BASE_URL + "/" + createdTodoId)
                            .header("Authorization", jwtToken))
                    .andExpect(status().isNotFound())
                    .andReturn().getResponse().getContentAsString();  // 삭제 후 응답 출력

            log.info("6-2. 삭제 후 조회 시 404 완료");
        } catch (Exception e) {
            log.error("6-3. 삭제 후 조회 시 404 중 에러 발생", e);
            throw e;
        }
    }
}
