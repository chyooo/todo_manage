package com.todomanage.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.todomanage.dto.UserDto;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TodoSecurityTest {

    private static final Logger log = LoggerFactory.getLogger(TodoSecurityTest.class);

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private static String jwtToken;
    private static final String BASE_URL = "/api/todos";

    private void setupWithLogin() throws Exception {
        log.info("0-1. 사용자 생성 및 로그인 시작");

        UserDto userDto = new UserDto();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String uniqueId = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        userDto.setUserId("testUser" + LocalDateTime.now().format(formatter) + uniqueId);
        userDto.setUserName("testUser");
        userDto.setPassword("testPassword");
        userDto.setEmail("test@example.com");

        log.info("0-2. 회원가입 요청 데이터: {}", objectMapper.writeValueAsString(userDto));

        // 회원가입 요청
        mockMvc.perform(post("/api/users/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isCreated());
        
        log.info("0-3. 회원가입 완료");

        // 로그인 요청
        MvcResult loginResult = mockMvc.perform(post("/api/users/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isOk())
                .andExpect(content().string(Matchers.matchesPattern("^\\S+\\.\\S+\\.\\S+$"))) // JWT 형식 확인
                .andReturn();

        String token = loginResult.getResponse().getContentAsString();
        jwtToken = "Bearer " + token;

        log.info("0-4. 로그인 완료 - JWT 발급: {}", jwtToken);
    }

    @Test
    @Order(1)
    void testGetInvalidTodo_shouldReturn404() throws Exception {
        // 로그인 수행
        setupWithLogin();
        
        log.info("1-1. 존재하지 않는 Todo ID 조회 테스트 시작");

        // 잘못된 Todo ID 설정
        int invalidTodoId = 999999;
        log.info("1-2. 잘못된 Todo ID({}) 조회 시도", invalidTodoId);

        // 요청을 보내고 결과를 확인
        MvcResult result = mockMvc.perform(get(BASE_URL + "/" + invalidTodoId)
                        .header("Authorization", jwtToken)) // JWT를 Authorization 헤더에 추가
                .andExpect(status().isNotFound()) // 404 상태 코드 예상
                .andReturn();

        log.info("1-3. 응답 상태 코드: {}", result.getResponse().getStatus());
    }
    
    @Test
    @Order(2)
    void testAccessWithoutJwt_shouldReturn401() throws Exception {
        log.info("2-1. JWT 없이 Todo 목록 접근 테스트 시작");

        // JWT 없이 요청을 보내고 결과를 확인
        MvcResult result = mockMvc.perform(get(BASE_URL))
                .andExpect(status().isUnauthorized()) // 401 상태 코드 예상
                .andReturn();

        log.info("2-2. 응답 상태 코드: {}", result.getResponse().getStatus());
    }
}
