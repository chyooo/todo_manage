package com.todomanage.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.todomanage.dto.UserDto;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
@AutoConfigureMockMvc
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private static final Logger log = LoggerFactory.getLogger(UserControllerTest.class);  // 변경된 로그 클래스

    @Test
    void testSignupAndLoginFlow() throws Exception {
        // 회원가입을 위한 UserDto 객체 생성
        UserDto userDto = new UserDto();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        userDto.setUserId("testUserId" + LocalDateTime.now().format(formatter));
        userDto.setUserName("testUser");
        userDto.setPassword("testPassword");
        userDto.setEmail("test@example.com");

        // 회원가입 테스트
        log.info("1. 회원가입 요청 시작");
        mockMvc.perform(post("/api/users/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(userDto)))
                .andExpect(status().isCreated())  // 상태 코드 확인
                .andDo(result -> log.info("1. 회원가입 응답: {}", result.getResponse().getContentAsString()));  // 응답 내용 출력

        // 로그인 테스트
        log.info("2. 로그인 요청 시작");
        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(userDto)))
                .andExpect(status().isOk())  // 상태 코드 확인
                .andDo(result -> log.info("2. 로그인 응답: {}", result.getResponse().getContentAsString()))  // 응답 내용 출력
                .andExpect(content().string(Matchers.matchesPattern("^\\S+\\.\\S+\\.\\S+$"))); // JWT 패턴
    }
}
